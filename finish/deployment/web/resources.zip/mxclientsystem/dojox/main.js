//>>built
define("dojox/main",["dojo/_base/kernel"],function(a){return a.dojox});
