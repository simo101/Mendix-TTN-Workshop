/*
	Copyright (c) 2004-2016, The JS Foundation All Rights Reserved.
	Available via Academic Free License >= 2.1 OR the modified BSD license.
	see: http://dojotoolkit.org/license for details
*/

//>>built
define("dojo/cldr/nls/nb/roc",{"field-sat-relative+0":"l\u00f8rdag denne uken","field-sat-relative+1":"l\u00f8rdag neste uke","field-dayperiod":"AM/PM","field-sun-relative+-1":"s\u00f8ndag sist uke","field-mon-relative+-1":"mandag sist uke","field-minute":"Minutt","field-day-relative+-1":"i g\u00e5r","field-weekday":"Ukedag","field-day-relative+-2":"i forg\u00e5rs","field-era":"Tidsalder","field-hour":"Time","field-sun-relative+0":"s\u00f8ndag denne uken","field-sun-relative+1":"s\u00f8ndag neste uke",
"field-wed-relative+-1":"onsdag sist uke","field-day-relative+0":"i dag","field-day-relative+1":"i morgen",eraAbbr:["Before R.O.C.","Minguo"],"field-day-relative+2":"i overmorgen","field-tue-relative+0":"tirsdag denne uken","field-zone":"Tidssone","field-tue-relative+1":"tirsdag neste uke","field-week-relative+-1":"Sist uke","field-year-relative+0":"Dette \u00e5ret","field-year-relative+1":"Neste \u00e5r","field-sat-relative+-1":"l\u00f8rdag sist uke","field-year-relative+-1":"I fjor","field-year":"\u00c5r",
"field-fri-relative+0":"fredag denne uken","field-fri-relative+1":"fredag neste uke","field-week":"Uke","field-week-relative+0":"Denne uken","field-week-relative+1":"Neste uke","field-month-relative+0":"Denne m\u00e5neden","field-month":"M\u00e5ned","field-month-relative+1":"Neste m\u00e5ned","field-fri-relative+-1":"fredag sist uke","field-second":"Sekund","field-tue-relative+-1":"tirsdag sist uke","field-day":"Dag","field-mon-relative+0":"mandag denne uken","field-mon-relative+1":"mandag neste uke",
"field-thu-relative+0":"torsdag denne uken","field-second-relative+0":"n\u00e5","field-thu-relative+1":"torsdag neste uke","field-wed-relative+0":"onsdag denne uken","field-wed-relative+1":"onsdag neste uke","field-month-relative+-1":"Sist m\u00e5ned","field-thu-relative+-1":"torsdag sist uke"});
