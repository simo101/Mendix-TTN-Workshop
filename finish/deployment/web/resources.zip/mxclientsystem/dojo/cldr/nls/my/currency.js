define(
//begin v1.x content
{
	"HKD_displayName": "ဟောင်ကောင် ဒေါ်လာ",
	"CHF_displayName": "ဆွစ် ဖရန့်",
	"JPY_symbol": "JP¥",
	"CAD_displayName": "ကနေဒါ ဒေါ်လာ",
	"HKD_symbol": "HK$",
	"CNY_displayName": "တရုတ် ယွမ်",
	"USD_symbol": "US$",
	"AUD_displayName": "ဩစတြေးလျ ဒေါ်လာ",
	"JPY_displayName": "ဂျပန်ယန်း",
	"CAD_symbol": "CA$",
	"USD_displayName": "အမေရိကန် ဒေါ်လာ",
	"EUR_symbol": "€",
	"CNY_symbol": "CN¥",
	"GBP_displayName": "ဗြိတိသျှ ပေါင်",
	"GBP_symbol": "£",
	"AUD_symbol": "A$",
	"EUR_displayName": "ယူရို"
}
//end v1.x content
);