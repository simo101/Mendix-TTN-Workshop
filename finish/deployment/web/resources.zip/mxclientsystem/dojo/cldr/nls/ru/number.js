/*
	Copyright (c) 2004-2016, The JS Foundation All Rights Reserved.
	Available via Academic Free License >= 2.1 OR the modified BSD license.
	see: http://dojotoolkit.org/license for details
*/

//>>built
define("dojo/cldr/nls/ru/number",{group:"\u00a0",percentSign:"%",exponential:"E",scientificFormat:"#E0",percentFormat:"#,##0\u00a0%",list:";",infinity:"\u221e",minusSign:"-",decimal:",",superscriptingExponent:"\u00d7",nan:"\u043d\u0435\u00a0\u0447\u0438\u0441\u043b\u043e",perMille:"\u2030",decimalFormat:"#,##0.###",currencyFormat:"#,##0.00\u00a0\u00a4",plusSign:"+","decimalFormat-long":"000 \u0442\u0440\u0438\u043b\u043b\u0438\u043e\u043d\u0430","decimalFormat-short":"000\u00a0\u0442\u0440\u043b\u043d"});
