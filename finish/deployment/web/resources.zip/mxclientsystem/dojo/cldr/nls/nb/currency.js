/*
	Copyright (c) 2004-2016, The JS Foundation All Rights Reserved.
	Available via Academic Free License >= 2.1 OR the modified BSD license.
	see: http://dojotoolkit.org/license for details
*/

//>>built
define("dojo/cldr/nls/nb/currency",{HKD_displayName:"Hongkong-dollar",CHF_displayName:"sveitsiske franc",JPY_symbol:"JPY",CAD_displayName:"kanadiske dollar",HKD_symbol:"HKD",CNY_displayName:"kinesiske yuan",USD_symbol:"USD",AUD_displayName:"australske dollar",JPY_displayName:"japanske yen",CAD_symbol:"CAD",USD_displayName:"amerikanske dollar",EUR_symbol:"\u20ac",CNY_symbol:"CNY",GBP_displayName:"britiske pund sterling",GBP_symbol:"\u00a3",AUD_symbol:"AUD",EUR_displayName:"euro"});
