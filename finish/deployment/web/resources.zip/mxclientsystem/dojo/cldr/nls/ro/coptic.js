/*
	Copyright (c) 2004-2016, The JS Foundation All Rights Reserved.
	Available via Academic Free License >= 2.1 OR the modified BSD license.
	see: http://dojotoolkit.org/license for details
*/

//>>built
define("dojo/cldr/nls/ro/coptic",{"field-sat-relative+0":"s\u00e2mb\u0103ta aceasta","field-sat-relative+1":"s\u00e2mb\u0103ta viitoare","field-dayperiod":"a.m./p.m","field-sun-relative+-1":"duminica trecut\u0103","field-mon-relative+-1":"lunea trecut\u0103","field-minute":"minut","field-day-relative+-1":"ieri","field-weekday":"zi a s\u0103pt\u0103m\u00e2nii","field-day-relative+-2":"alalt\u0103ieri","field-era":"er\u0103","field-hour":"or\u0103","field-sun-relative+0":"duminica aceasta","field-sun-relative+1":"duminica viitoare",
"field-wed-relative+-1":"miercurea trecut\u0103","field-day-relative+0":"azi","field-day-relative+1":"m\u00e2ine","field-day-relative+2":"poim\u00e2ine","field-tue-relative+0":"mar\u021bea aceasta","field-zone":"fus orar","field-tue-relative+1":"mar\u021bea viitoare","field-week-relative+-1":"s\u0103pt\u0103m\u00e2na trecut\u0103","field-year-relative+0":"anul acesta","field-year-relative+1":"anul viitor","field-sat-relative+-1":"s\u00e2mb\u0103ta trecut\u0103","field-year-relative+-1":"anul trecut",
"field-year":"an","field-fri-relative+0":"vinerea aceasta","field-fri-relative+1":"vinerea viitoare","field-week":"s\u0103pt\u0103m\u00e2n\u0103","field-week-relative+0":"s\u0103pt\u0103m\u00e2na aceasta","field-week-relative+1":"s\u0103pt\u0103m\u00e2na viitoare","field-month-relative+0":"luna aceasta","field-month":"lun\u0103","field-month-relative+1":"luna viitoare","field-fri-relative+-1":"vinerea trecut\u0103","field-second":"secund\u0103","field-tue-relative+-1":"mar\u021bea trecut\u0103","field-day":"zi",
"field-mon-relative+0":"lunea aceasta","field-mon-relative+1":"lunea viitoare","field-thu-relative+0":"joia aceasta","field-second-relative+0":"acum","field-thu-relative+1":"joia viitoare","field-wed-relative+0":"miercurea aceasta","field-wed-relative+1":"miercurea viitoare","field-month-relative+-1":"luna trecut\u0103","field-thu-relative+-1":"joia trecut\u0103"});
