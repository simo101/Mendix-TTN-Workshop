/*
	Copyright (c) 2004-2016, The JS Foundation All Rights Reserved.
	Available via Academic Free License >= 2.1 OR the modified BSD license.
	see: http://dojotoolkit.org/license for details
*/

//>>built
define("dojo/cldr/nls/sk/currency",{HKD_displayName:"Hongkonsk\u00fd dol\u00e1r",CHF_displayName:"\u0160vaj\u010diarsky frank",JPY_symbol:"JPY",CAD_displayName:"Kanadsk\u00fd dol\u00e1r",HKD_symbol:"HKD",CNY_displayName:"\u010c\u00ednsky j\u00fcan",USD_symbol:"USD",AUD_displayName:"Austr\u00e1lsky dol\u00e1r",JPY_displayName:"Japonsk\u00fd jen",CAD_symbol:"CAD",USD_displayName:"Americk\u00fd dol\u00e1r",EUR_symbol:"\u20ac",CNY_symbol:"CNY",GBP_displayName:"Britsk\u00e1 libra",GBP_symbol:"GBP",AUD_symbol:"AUD",
EUR_displayName:"Euro"});
