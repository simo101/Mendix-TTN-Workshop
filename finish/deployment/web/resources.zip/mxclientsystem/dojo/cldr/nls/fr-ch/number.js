/*
	Copyright (c) 2004-2016, The JS Foundation All Rights Reserved.
	Available via Academic Free License >= 2.1 OR the modified BSD license.
	see: http://dojotoolkit.org/license for details
*/

//>>built
define("dojo/cldr/nls/fr-ch/number",{currencyFormat:"\u00a4\u00a0#,##0.00;\u00a4-#,##0.00",group:"'",decimal:"."});
