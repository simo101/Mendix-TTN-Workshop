/*
	Copyright (c) 2004-2016, The JS Foundation All Rights Reserved.
	Available via Academic Free License >= 2.1 OR the modified BSD license.
	see: http://dojotoolkit.org/license for details
*/

//>>built
define("dojo/cldr/nls/fr/currency",{HKD_displayName:"dollar de Hong Kong",CHF_displayName:"franc suisse",JPY_symbol:"\u00a5JP",CAD_displayName:"dollar canadien",HKD_symbol:"$HK",CNY_displayName:"yuan renminbi chinois",USD_symbol:"$US",AUD_displayName:"dollar australien",JPY_displayName:"yen japonais",CAD_symbol:"$CA",USD_displayName:"dollar des \u00c9tats-Unis",EUR_symbol:"\u20ac",CNY_symbol:"\u00a5CN",GBP_displayName:"livre sterling",GBP_symbol:"\u00a3GB",AUD_symbol:"$AU",EUR_displayName:"euro"});
